# Bill API

This is a Spring Boot Java application that exposes an API for calculating the net payable amount of a bill.

## Running the application

1. Ensure you have Java and Maven installed on your system.
2. Clone the repository or download the source code.
3. Open a terminal and navigate to the project directory.
4. Run the following command to build the application:
   mvn clean package

5. The application will start running on `http://localhost:8080`.
6. You can acces swagger using http://localhost:8080/swagger-ui/
