package com.example.demo;

public class User {
    private boolean isEmployee;
    private boolean isAffiliate;
    private boolean isCustomerOver2Years;
    private boolean isGroceries;

    public User(boolean isEmployee, boolean isAffiliate, boolean isCustomerOver2Years, boolean isGroceries) {
        this.isEmployee = isEmployee;
        this.isAffiliate = isAffiliate;
        this.isCustomerOver2Years = isCustomerOver2Years;
        this.isGroceries = isGroceries;
    }

    public boolean isEmployee() {
        return isEmployee;
    }

    public boolean isAffiliate() {
        return isAffiliate;
    }

    public boolean isCustomerOver2Years() {
        return isCustomerOver2Years;
    }

    public boolean isGroceries() {
        return isGroceries;
    }
}

