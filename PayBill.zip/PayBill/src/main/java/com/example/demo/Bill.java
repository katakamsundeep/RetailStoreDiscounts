package com.example.demo;

public class Bill {
    private double amount;

    public Bill(double amount) {
        this.amount = amount;
    }
    
    public Bill() {
        
    }

    public double getAmount() {
        return amount;
    }
}

