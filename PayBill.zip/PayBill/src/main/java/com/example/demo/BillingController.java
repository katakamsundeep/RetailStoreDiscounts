package com.example.demo;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BillingController {
    private BillingService billingService;

    public BillingController(BillingService billingService) {
        this.billingService = billingService;
    }

    @PostMapping("/netPayableAmount")
    public double calculateNetPayableAmount(@RequestBody BillRequest billRequest) {
        User user = billRequest.getUser();
        Bill bill = billRequest.getBill();
        return billingService.calculateNetPayableAmount(user, bill);
    }
}
