package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class BillingService {
    private List<Discount> discounts;

    public BillingService() {
        discounts = new ArrayList<>();
        discounts.add(new Discount("Employee", 0.3));
        discounts.add(new Discount("Affiliate", 0.1));
        discounts.add(new Discount("CustomerOver2Years", 0.05));
    }

    public double calculateNetPayableAmount(User user, Bill bill) {
        double netPayableAmount = bill.getAmount();

        if (!user.isGroceries()) {
            Discount percentageDiscount = getPercentageDiscount(user);
            if (percentageDiscount != null) {
                netPayableAmount -= bill.getAmount() * percentageDiscount.getValue();
            }
        }

        double fixedDiscount = getFixedDiscount(bill.getAmount());
        netPayableAmount -= fixedDiscount;

        return netPayableAmount;
    }

    private Discount getPercentageDiscount(User user) {
        for (Discount discount : discounts) {
            if (isDiscountApplicable(user, discount) && !user.isGroceries()) {
                return discount;
            }
        }
        return null;
    }


    private boolean isDiscountApplicable(User user, Discount discount) {
        if (discount.getType().equals("Employee") && user.isEmployee()) {
            return true;
        } else if (discount.getType().equals("Affiliate") && user.isAffiliate()) {
            return true;
        } else return discount.getType().equals("CustomerOver2Years") && user.isCustomerOver2Years();
    }

    private double getFixedDiscount(double amount) {
    	int discountAmount = (int) (amount / 100) * 5;
        return discountAmount;
    }
}
