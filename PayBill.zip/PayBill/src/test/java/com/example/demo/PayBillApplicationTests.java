package com.example.demo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class PayBillApplicationTests {

    @Test
    public void testCalculateNetPayableAmount_EmployeeDiscount() {
        // Arrange
        BillingService billingService = new BillingService();
        User user = new User(true, false, false, false);
        Bill bill = new Bill(1000);

        // Act
        double netPayableAmount = billingService.calculateNetPayableAmount(user, bill);

        // Assert
        Assertions.assertEquals(695.0, netPayableAmount);
    }

    @Test
    public void testCalculateNetPayableAmount_AffiliateDiscount() {
        // Arrange
        BillingService billingService = new BillingService();
        User user = new User(false, true, false, false);
        Bill bill = new Bill(1000);

        // Act
        double netPayableAmount = billingService.calculateNetPayableAmount(user, bill);

        // Assert
        Assertions.assertEquals(855.0, netPayableAmount);
    }

    @Test
    public void testCalculateNetPayableAmount_CustomerOver2YearsDiscount() {
        // Arrange
        BillingService billingService = new BillingService();
        User user = new User(false, false, true, false);
        Bill bill = new Bill(1000);

        // Act
        double netPayableAmount = billingService.calculateNetPayableAmount(user, bill);

        // Assert
        Assertions.assertEquals(950.0, netPayableAmount);
    }

    @Test
    public void testCalculateNetPayableAmount_PercentageDiscountNotApplicable() {
        // Arrange
        BillingService billingService = new BillingService();
        User user = new User(false, false, false, true);
        Bill bill = new Bill(1000);

        // Act
        double netPayableAmount = billingService.calculateNetPayableAmount(user, bill);

        // Assert
        Assertions.assertEquals(995.0, netPayableAmount);
    }

    @Test
    public void testCalculateNetPayableAmount_FixedDiscount() {
        // Arrange
        BillingService billingService = new BillingService();
        User user = new User(false, false, false, false);
        Bill bill = new Bill(990);

        // Act
        double netPayableAmount = billingService.calculateNetPayableAmount(user, bill);

        // Assert
        Assertions.assertEquals(940.0, netPayableAmount);
    }

    @Test
    public void testCalculateNetPayableAmount_AllDiscountsApplicable() {
        // Arrange
        BillingService billingService = new BillingService();
        User user = new User(true, true, true, false);
        Bill bill = new Bill(2000);

        // Act
        double netPayableAmount = billingService.calculateNetPayableAmount(user, bill);

        // Assert
        Assertions.assertEquals(1295.0, netPayableAmount);
    }
}

